#Get a Random Number

import random
def main(size):
	return random.randint(0, size)